<?php namespace Config;

class ForeignCharacters extends \CodeIgniter\Config\ForeignCharacters
{

}
